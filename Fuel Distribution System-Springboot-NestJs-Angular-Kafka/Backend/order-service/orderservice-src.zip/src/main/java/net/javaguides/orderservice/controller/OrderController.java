package net.javaguides.orderservice.controller;


import net.javaguides.basedomains.dto.Order;
import net.javaguides.basedomains.dto.OrderEvent;
import net.javaguides.basedomains.dto.ScheduleEvent;
import net.javaguides.orderservice.kafka.OrderProducer;
import net.javaguides.orderservice.kafka.ScheduleConsumer;
import net.javaguides.orderservice.kafka.StockConsumer;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
@RequestMapping("/api/v1")
public class OrderController {

private OrderProducer orderProducer;

    public OrderController(OrderProducer orderProducer) {
        this.orderProducer = orderProducer;
    }

    @PostMapping("/orders")
    public OrderEvent placeOrder(@RequestBody Order order){
        order.setOrderId(UUID.randomUUID().toString());

        OrderEvent orderEvent=new OrderEvent();

        orderEvent.setOrder(order);

        orderProducer.sendMessage(orderEvent);

        try {
            Thread.sleep(10 * 1000);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }

        return StockConsumer.os;


    }
public Order createOrder(@RequestBody Order order){
        return null;
}


}
