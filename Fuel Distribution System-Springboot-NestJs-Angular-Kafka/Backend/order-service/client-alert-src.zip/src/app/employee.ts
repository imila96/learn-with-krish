import { CreateEmployeeComponent } from "./create-employee/create-employee.component";

export class Employee {
    orderId: String;
    fuelType: string;
    qty: number;
    status: string;
}
